import { motion } from 'motion/react';

export default function Signature() {
  return (
    <section className="section-padding bg-coffee-100 overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="bg-white rounded-[3rem] overflow-hidden shadow-2xl flex flex-col lg:flex-row">
          <div className="lg:w-1/2 p-12 md:p-20 flex flex-col justify-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-coffee-500 uppercase tracking-[0.2em] text-sm font-bold mb-4 block">
                Featured Drink
              </span>
              <h2 className="heading-serif text-4xl md:text-5xl text-coffee-900 mb-6">
                The Pistachio <br />
                <span className="italic">Specialty Latte</span>
              </h2>
              <p className="text-coffee-700 text-lg leading-relaxed mb-8">
                Our signature creation. A perfect balance of double-shot espresso, 
                house-made pistachio cream, and velvety steamed milk, topped with 
                crushed roasted pistachios. A taste of Madrid's finest.
              </p>
              <div className="flex items-center gap-6">
                <span className="heading-serif text-3xl text-coffee-800">€5.80</span>
                <button className="btn-primary">Try It Today</button>
              </div>
            </motion.div>
          </div>
          
          <div className="lg:w-1/2 relative min-h-[400px]">
            <motion.img
              initial={{ scale: 1.2, opacity: 0 }}
              whileInView={{ scale: 1, opacity: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 1.2 }}
              src="https://images.unsplash.com/photo-1572286258217-40142c1c6a70?q=80&w=2070&auto=format&fit=crop"
              alt="Signature Latte"
              className="absolute inset-0 w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-r from-white/20 to-transparent lg:hidden" />
          </div>
        </div>
      </div>
    </section>
  );
}
