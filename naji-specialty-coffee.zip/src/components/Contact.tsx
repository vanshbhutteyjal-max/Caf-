import { motion } from 'motion/react';
import { MapPin, Phone, Clock, Navigation, ExternalLink } from 'lucide-react';

export default function Contact() {
  return (
    <section id="contact" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <motion.div
            initial={{ opacity: 0, x: -30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <span className="text-coffee-500 uppercase tracking-[0.2em] text-sm font-bold mb-4 block">
              Visit Us
            </span>
            <h2 className="heading-serif text-4xl md:text-5xl text-coffee-900 mb-8">
              Find Your Way to <br />
              Naji Coffee
            </h2>

            <div className="space-y-8 mb-12">
              <div className="flex gap-4">
                <div className="bg-coffee-100 p-3 rounded-xl h-fit">
                  <MapPin className="w-6 h-6 text-coffee-800" />
                </div>
                <div>
                  <h4 className="font-bold text-coffee-900 mb-1">Address</h4>
                  <p className="text-coffee-600">C. del Cardenal Cisneros, 39, Chamberí, 28010 Madrid, Spain</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="bg-coffee-100 p-3 rounded-xl h-fit">
                  <Phone className="w-6 h-6 text-coffee-800" />
                </div>
                <div>
                  <h4 className="font-bold text-coffee-900 mb-1">Phone</h4>
                  <p className="text-coffee-600">+34 699 04 28 41</p>
                </div>
              </div>

              <div className="flex gap-4">
                <div className="bg-coffee-100 p-3 rounded-xl h-fit">
                  <Clock className="w-6 h-6 text-coffee-800" />
                </div>
                <div>
                  <h4 className="font-bold text-coffee-900 mb-1">Opening Hours</h4>
                  <div className="text-coffee-600 space-y-1">
                    <p className="flex justify-between w-48"><span>Mon – Fri:</span> <span>8:00 – 18:00</span></p>
                    <p className="flex justify-between w-48"><span>Sat – Sun:</span> <span>9:00 – 19:00</span></p>
                  </div>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-4">
              <a 
                href="tel:+34699042841" 
                className="btn-primary flex items-center gap-2"
              >
                <Phone className="w-4 h-4" /> Call Now
              </a>
              <a 
                href="https://maps.app.goo.gl/T3UZEZZLgJG62cxEA" 
                target="_blank" 
                rel="noopener noreferrer"
                className="btn-secondary flex items-center gap-2"
              >
                <Navigation className="w-4 h-4" /> Get Directions
              </a>
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
            className="relative h-[400px] lg:h-full rounded-3xl overflow-hidden shadow-xl border border-coffee-100"
          >
            {/* Embedded Google Map - Placeholder for real map iframe */}
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3037.039757643542!2d-3.704288123440788!3d40.430094171437!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xd4228f498964977%3A0x67699042841!2sC.%20del%20Cardenal%20Cisneros%2C%2039%2C%2028010%20Madrid%2C%20Spain!5e0!3m2!1sen!2sus!4v1712150000000!5m2!1sen!2sus"
              className="absolute inset-0 w-full h-full grayscale hover:grayscale-0 transition-all duration-500"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
            ></iframe>
            <div className="absolute top-4 right-4 bg-white p-3 rounded-full shadow-lg">
              <ExternalLink className="w-5 h-5 text-coffee-800" />
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
