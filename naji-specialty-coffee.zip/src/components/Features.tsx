import { motion } from 'motion/react';
import { Award, Users, Coffee, Croissant } from 'lucide-react';

const features = [
  {
    icon: <Award className="w-8 h-8" />,
    title: 'Premium Beans',
    desc: 'We source only the highest grade specialty beans from sustainable farms.',
  },
  {
    icon: <Users className="w-8 h-8" />,
    title: 'Expert Baristas',
    desc: 'Our team is trained in the latest brewing techniques and flavor science.',
  },
  {
    icon: <Coffee className="w-8 h-8" />,
    title: 'Madrid Ambiance',
    desc: 'A cozy, minimalist space designed for relaxation and community.',
  },
  {
    icon: <Croissant className="w-8 h-8" />,
    title: 'Fresh Pastries',
    desc: 'Handcrafted pastries delivered fresh every morning from local bakeries.',
  },
];

export default function Features() {
  return (
    <section className="section-padding bg-coffee-950 text-white">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {features.map((feature, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="flex flex-col items-center text-center group"
            >
              <div className="mb-6 text-coffee-300 group-hover:text-coffee-100 transition-colors duration-300">
                {feature.icon}
              </div>
              <h3 className="heading-serif text-xl mb-4">{feature.title}</h3>
              <p className="text-coffee-300/80 text-sm leading-relaxed">
                {feature.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
