import { motion } from 'motion/react';

const menuItems = {
  Espresso: [
    { name: 'Espresso', price: '2.50', desc: 'Single shot of our house blend' },
    { name: 'Double Espresso', price: '3.20', desc: 'Two shots of rich, balanced espresso' },
    { name: 'Americano', price: '3.50', desc: 'Espresso with hot water' },
  ],
  'Milk Based': [
    { name: 'Latte', price: '4.20', desc: 'Espresso with steamed milk and thin foam' },
    { name: 'Cappuccino', price: '4.00', desc: 'Equal parts espresso, milk, and foam' },
    { name: 'Flat White', price: '4.20', desc: 'Double espresso with microfoam' },
    { name: 'Cortado', price: '3.50', desc: 'Espresso cut with a small amount of warm milk' },
  ],
  'Specialty Drinks': [
    { name: 'V60 Pour Over', price: '5.50', desc: 'Clean, complex flavor profile' },
    { name: 'Cold Brew', price: '4.80', desc: 'Steeped for 18 hours for smoothness' },
    { name: 'Matcha Latte', price: '5.00', desc: 'Ceremonial grade matcha with milk' },
  ],
  'Pastries & Bites': [
    { name: 'Butter Croissant', price: '3.00', desc: 'Flaky, buttery, and fresh' },
    { name: 'Avocado Toast', price: '8.50', desc: 'Sourdough with poached egg' },
    { name: 'Lemon Cake', price: '4.50', desc: 'Zesty and moist homemade cake' },
  ],
};

export default function Menu() {
  return (
    <section id="menu" className="section-padding bg-coffee-100/50">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-coffee-500 uppercase tracking-[0.2em] text-sm font-bold mb-4 block">
            Our Selection
          </span>
          <h2 className="heading-serif text-4xl md:text-5xl text-coffee-900 mb-6">
            The Coffee Menu
          </h2>
          <p className="text-coffee-600 max-w-xl mx-auto">
            Explore our curated selection of specialty coffees, hand-crafted drinks, 
            and delicious light bites.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 lg:gap-20">
          {Object.entries(menuItems).map(([category, items], idx) => (
            <motion.div
              key={category}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
            >
              <h3 className="heading-serif text-2xl text-coffee-800 mb-8 border-b border-coffee-200 pb-2">
                {category}
              </h3>
              <div className="space-y-8">
                {items.map((item) => (
                  <div key={item.name} className="group">
                    <div className="flex justify-between items-end mb-2">
                      <h4 className="font-medium text-coffee-900 group-hover:text-coffee-600 transition-colors">
                        {item.name}
                      </h4>
                      <span className="text-coffee-800 font-serif">€{item.price}</span>
                    </div>
                    <p className="text-sm text-coffee-500 italic">{item.desc}</p>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 text-center">
          <p className="text-coffee-500 text-sm mb-8">
            * Seasonal beans and guest roasters available. Ask our baristas for today's selection.
          </p>
          <button className="btn-primary">Download Full Menu</button>
        </div>
      </div>
    </section>
  );
}
