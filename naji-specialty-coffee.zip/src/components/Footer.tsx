import { Coffee, Instagram, Facebook, Twitter } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-coffee-950 text-white pt-20 pb-10 px-6">
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-16">
          <div className="col-span-1 lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-6">
              <div className="bg-coffee-800 p-1.5 rounded-lg">
                <Coffee className="w-6 h-6 text-white" />
              </div>
              <span className="heading-serif text-2xl font-bold tracking-widest uppercase">
                Naji
              </span>
            </a>
            <p className="text-coffee-300 text-sm leading-relaxed mb-8">
              Crafting exceptional specialty coffee experiences in the heart of Madrid. 
              Quality, community, and craftsmanship in every cup.
            </p>
            <div className="flex gap-4">
              <a href="#" className="bg-coffee-900 p-2 rounded-full hover:bg-coffee-800 transition-colors">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="bg-coffee-900 p-2 rounded-full hover:bg-coffee-800 transition-colors">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="bg-coffee-900 p-2 rounded-full hover:bg-coffee-800 transition-colors">
                <Twitter className="w-5 h-5" />
              </a>
            </div>
          </div>

          <div>
            <h4 className="heading-serif text-lg mb-6">Quick Links</h4>
            <ul className="space-y-4 text-coffee-300 text-sm">
              <li><a href="#" className="hover:text-white transition-colors">Home</a></li>
              <li><a href="#about" className="hover:text-white transition-colors">About Us</a></li>
              <li><a href="#menu" className="hover:text-white transition-colors">Our Menu</a></li>
              <li><a href="#gallery" className="hover:text-white transition-colors">Gallery</a></li>
              <li><a href="#contact" className="hover:text-white transition-colors">Contact</a></li>
            </ul>
          </div>

          <div>
            <h4 className="heading-serif text-lg mb-6">Contact Info</h4>
            <ul className="space-y-4 text-coffee-300 text-sm">
              <li>C. del Cardenal Cisneros, 39</li>
              <li>Chamberí, 28010 Madrid</li>
              <li>+34 699 04 28 41</li>
              <li>hello@najicoffee.es</li>
            </ul>
          </div>

          <div>
            <h4 className="heading-serif text-lg mb-6">Newsletter</h4>
            <p className="text-coffee-300 text-sm mb-6">
              Join our community and get updates on new roasts and events.
            </p>
            <form className="flex gap-2">
              <input 
                type="email" 
                placeholder="Your email" 
                className="bg-coffee-900 border-none rounded-lg px-4 py-2 text-sm w-full focus:ring-1 focus:ring-coffee-500 outline-none"
              />
              <button className="bg-coffee-800 px-4 py-2 rounded-lg text-sm font-bold hover:bg-coffee-700 transition-colors">
                Join
              </button>
            </form>
          </div>
        </div>

        <div className="border-t border-coffee-900 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-coffee-500 text-xs uppercase tracking-widest">
          <p>© 2024 Naji Specialty Coffee. All rights reserved.</p>
          <div className="flex gap-8">
            <a href="#" className="hover:text-white">Privacy Policy</a>
            <a href="#" className="hover:text-white">Terms of Service</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
