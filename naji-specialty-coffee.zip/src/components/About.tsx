import { motion } from 'motion/react';

export default function About() {
  return (
    <section id="about" className="section-padding bg-white">
      <div className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
          className="relative"
        >
          <div className="aspect-[4/5] rounded-2xl overflow-hidden shadow-2xl">
            <img
              src="https://images.unsplash.com/photo-1442512595331-e89e73853f31?q=80&w=2070&auto=format&fit=crop"
              alt="Barista at work"
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="absolute -bottom-8 -right-8 bg-coffee-800 text-white p-8 rounded-2xl hidden md:block shadow-xl">
            <p className="heading-serif text-4xl font-bold mb-1">10+</p>
            <p className="text-xs uppercase tracking-widest opacity-80">Years of Craft</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 50 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8 }}
        >
          <span className="text-coffee-500 uppercase tracking-[0.2em] text-sm font-bold mb-4 block">
            Our Story
          </span>
          <h2 className="heading-serif text-4xl md:text-5xl text-coffee-900 mb-8 leading-tight">
            A Passion for the <br />
            Perfect Roast
          </h2>
          <div className="space-y-6 text-coffee-700 leading-relaxed text-lg">
            <p>
              Located in the vibrant Chamberí neighborhood of Madrid, Naji Specialty Coffee 
              was born from a simple dream: to serve the finest specialty coffee in an 
              atmosphere that feels like home.
            </p>
            <p>
              We believe that coffee is more than just a drink—it's a craft. Every bean 
              we source is ethically produced and roasted to perfection to highlight its 
              unique origin and flavor profile.
            </p>
            <p>
              Our expert baristas are dedicated to the art of brewing, ensuring that every 
              cup we serve meets our uncompromising standards of quality and craftsmanship.
            </p>
          </div>
          
          <div className="mt-12 grid grid-cols-2 gap-8 border-t border-coffee-100 pt-12">
            <div>
              <h4 className="heading-serif text-xl text-coffee-900 mb-2">Quality Beans</h4>
              <p className="text-sm text-coffee-600">Sourced from the best high-altitude farms globally.</p>
            </div>
            <div>
              <h4 className="heading-serif text-xl text-coffee-900 mb-2">Expert Brewing</h4>
              <p className="text-sm text-coffee-600">Precision and passion in every single extraction.</p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
