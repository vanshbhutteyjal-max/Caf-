import { motion } from 'motion/react';
import { Star, Quote } from 'lucide-react';

const testimonials = [
  {
    name: 'Elena Rodriguez',
    role: 'Coffee Enthusiast',
    text: 'The best flat white in Madrid. The atmosphere is so peaceful, perfect for a morning read.',
    rating: 5,
  },
  {
    name: 'Marco Silva',
    role: 'Local Resident',
    text: 'Naji has become my daily ritual. The staff is incredibly knowledgeable and the pastries are divine.',
    rating: 5,
  },
  {
    name: 'Sarah Jenkins',
    role: 'Digital Nomad',
    text: 'Great WiFi, even better coffee. The V60 pour over is a must-try for any true coffee lover.',
    rating: 5,
  },
];

export default function Testimonials() {
  return (
    <section className="section-padding bg-coffee-100/30">
      <div className="max-w-7xl mx-auto">
        <div className="text-center mb-16">
          <span className="text-coffee-500 uppercase tracking-[0.2em] text-sm font-bold mb-4 block">
            Reviews
          </span>
          <h2 className="heading-serif text-4xl md:text-5xl text-coffee-900 mb-6">
            What Our Guests Say
          </h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((t, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-white p-8 rounded-2xl shadow-sm border border-coffee-100 relative"
            >
              <Quote className="absolute top-6 right-8 w-10 h-10 text-coffee-100" />
              <div className="flex gap-1 mb-4">
                {[...Array(t.rating)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-coffee-400 text-coffee-400" />
                ))}
              </div>
              <p className="text-coffee-700 italic mb-8 leading-relaxed">
                "{t.text}"
              </p>
              <div>
                <h4 className="font-bold text-coffee-900">{t.name}</h4>
                <p className="text-xs text-coffee-500 uppercase tracking-widest">{t.role}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
